import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const CheckboxComp = () => {
  return (
    <View>
      <Text>CheckboxComp</Text>
    </View>
  )
}

export default CheckboxComp

const styles = StyleSheet.create({})