import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const RadioCompType9 = () => {
  return (
    <View>
      <Text>RadioCompType9</Text>
    </View>
  )
}

export default RadioCompType9

const styles = StyleSheet.create({})