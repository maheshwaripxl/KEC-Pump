import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const RadioCompType4 = () => {
  return (
    <View>
      <Text>RadioCompType4</Text>
    </View>
  )
}

export default RadioCompType4

const styles = StyleSheet.create({})