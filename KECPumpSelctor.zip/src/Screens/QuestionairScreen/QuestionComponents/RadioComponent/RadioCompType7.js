import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const RadioCompType7 = () => {
  return (
    <View>
      <Text>RadioCompType7</Text>
    </View>
  )
}

export default RadioCompType7

const styles = StyleSheet.create({})