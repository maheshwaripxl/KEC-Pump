import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const RadioCompType6 = () => {
  return (
    <View>
      <Text>RadioCompType6</Text>
    </View>
  )
}

export default RadioCompType6

const styles = StyleSheet.create({})