export const QuesPage = [
  {
    ques: 'Do you need a pump from a specific technology group?',
    opt: 'No, please consider all pumps.',
    // opt2: 'Yes, a centrifugal pump.',
    // opt3: 'Yes, a positive displacement pump.',
  },
  {
    ques: 'Do you need a pump from a specific technology group?',
    opt: 'No, please consider all pumps.',
    // opt2: 'Yes, a centrifugal pump.',
    // opt3: 'Yes, a positive displacement pump.',
  },

  //   {
  //     ques: 'Which fluid will be pumped?',
  //   },

  //   {
  //     ques: 'What is the Hazard Potential of the medium?',
  //     opt1: 'None',
  //     opt2: 'Low',
  //     opt3: 'Medium',
  //     opt4: 'High',
  //   },

  //   {
  //     ques: 'What is the viscosity of the fluid?',
  //     ques2: 'What is the pump output?',
  //   },

  //   {
  //     ques: 'What is the differential delivery head or differential delivery pressure?',
  //     ques2: 'What temperature will the fluid handled have?',
  //   },

  //   {
  //     ques: 'Will your pump be installed horizontally or vertically?',
  //     opt1: 'Horizontal',
  //     opt2: 'Vertical',
  //     opt3: 'Both possible'
  //   },
];
